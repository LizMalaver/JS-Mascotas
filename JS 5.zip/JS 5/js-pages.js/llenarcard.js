let NombreMascotaAgregar = document.getElementById('NombreMascota');
let DescripcionMascotaAgregar = document.getElementById ("DescribeMascota");
let RazaMascotaAgregar = document.getElementById ("RazaMascota");
let TamañoMascotaAgregar = document.getElementById ("TamanoMascota");
let PesoMascotaAgregar = document.getElementById ("PesoMascota");
let EdadMascotaAgregar = document.getElementById ("EdadMascota");


let NombreMascotaCardGeneral = document.querySelector('#CardNombreMascota');
let DescripcionCardGeneral = document.querySelector(".CardGeneralDescripcion");
let RazaCardGeneral = document.getElementById ("CardGeneralRaza");
let TamañoCardGeneral = document.getElementById ("CardGeneralTamano");
let PesoCardGeneral = document.getElementById ("CardGeneralPeso");
let EdadCardGeneral = document.getElementById ("CardGeneralEdad");
let ComidaCardGeneral = document.getElementById ("CardGeneralComida");

/*
NombreMascotaAgregar.onkeydown= () => {
NombreMascotaCardGeneral.innerHTML = NombreMascotaAgregar.value;
};*/

/*NombreMascotaAgregar.addEventListener ('input',() => {
    if(NombreMascotaAgregar.value == ''){
        NombreMascotaCardGeneral.innerText = 'Ingresa un nombre'
    } else {
        NombreMascotaCardGeneral.innerText = NombreMascotaAgregar.value;
    }
});*/

NombreMascotaAgregar.addEventListener ('input',() => {
    NombreMascotaCardGeneral.innerText = NombreMascotaAgregar.value;
   
});